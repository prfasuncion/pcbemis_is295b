<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top text-white">
  <div class="container">
    <div class="navbar-wrapper">
      <a class="navbar-brand" href="{{ route('home') }}">{{ $title }}</a>
      <a class="navbar-brand" href="{{ url('/jobs') }}">{{ 'Job Opportunities' }}</a>
    </div>
   
    
  </div>
</nav>
<!-- End Navbar -->